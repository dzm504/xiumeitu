SET NAMES UTF8;
DROP DATABASE IF EXISTS xiumeitu_msg;
CREATE DATABASE xiumeitu_msg CHARSET=UTF8;
USE xiumeitu_msg;
CREATE TABLE messages(
  mid INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(64),
  msg VARCHAR(1024),
  createTime BIGINT    
);	
INSERT INTO messages VALUES(
  NULL, 'dzm','网站内容不错，希望多增加点网站素材供下载，还有就是更新要快一点，望采纳！！！','1473951698228'
);
INSERT INTO messages VALUES(
  NULL, 'dzm','网站内容不错，希望多增加点网站素材供下载，还有就是更新要快一点，望采纳！！！','1473951698228'
);
INSERT INTO messages VALUES(
  NULL, 'dzm','网站内容不错，希望多增加点网站素材供下载，还有就是更新要快一点，望采纳！！！','1473951698228'
);
INSERT INTO messages VALUES(
  NULL, 'dzm','网站内容不错，希望多增加点网站素材供下载，还有就是更新要快一点，望采纳！！！','1473951698228'
);
INSERT INTO messages VALUES(
  NULL, 'dzm','网站内容不错，希望多增加点网站素材供下载，还有就是更新要快一点，望采纳！！！','1473951698228'
);
INSERT INTO messages VALUES(
  NULL, 'dzm','网站内容不错，希望多增加点网站素材供下载，还有就是更新要快一点，望采纳！！！','1473951698228'
);
INSERT INTO messages VALUES(
  NULL, 'dzm','网站内容不错，希望多增加点网站素材供下载，还有就是更新要快一点，望采纳！！！','1473951698228'
);
INSERT INTO messages VALUES(
  NULL, 'dzm','网站内容不错，希望多增加点网站素材供下载，还有就是更新要快一点，望采纳！！！','1473951698228'
);




